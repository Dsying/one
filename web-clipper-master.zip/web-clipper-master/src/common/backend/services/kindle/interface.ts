export interface MailBackendServiceConfig {
  to: string;
  domain: string;
}
