export interface MailBackendServiceConfig {
  to: string;
  home: string;
  html: boolean;
}
