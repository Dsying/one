export function getCommitsCount(): number;
